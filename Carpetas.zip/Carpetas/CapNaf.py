import pandas as pd
import numpy as np
import pyodbc
import tkinter as tk
from tkinter import * 
from tkinter.ttk import *
from tkinter.font import Font
import shutil
from pathlib import Path
import os
from openpyxl import Workbook


def crear_excel():

    server = 'datawarehouse'
    database ='DWH_CORP'

    #Lectura del arhivo con la consulta SQL que se va a ejecutar desde el archivo
    with open('NafNaf.sql', 'r' ) as file:
        query_tmp = file.read()


    # cadena = '@marca = 34'
    # rem = cadena.replace('34',"'34'")
    # print(rem)
    marcast = ['Esprit','Mng','Outlet Todo al 50%','Brand Store','Carrera','Chevignon','Rifle','Americanino','Naf Naf','American Eagle','G-star']
    #Lista de 
    
    for marca in marcast:
        total_marcas = []
        for fec in range(1):
                
            query_one = f'@cambioMesAnterior = {"-" if fec != 0 else ""}{fec}'
            query_two = f'@cambioDosMesAnt = -{fec + 1}'
            
                
            try:
                    
                    
                    #Establecer conexión con la base de datos
                conexion =  f'DRIVER={{SQL Server}};' \
                                f'SERVER={server};' \
                                f'DATABASE={database};'

                conexion = pyodbc.connect(conexion)

                cursor = conexion.cursor()
                                
                
                #marcas = ['@marca = "'34'"]
                    #print("correcto")
                
                query_tmp2 = query_tmp.replace('@cambioMesAnterior = 9', query_one)
                query_tmp3=query_tmp2.replace('@cambioDosMesAnt = 10', query_two)
                
                
                query_tmp4 = query_tmp3.replace('marcaaa', marca)
                
                query_tmp5 = query_tmp4.replace('grupooooo',marca)
                
                datos = pd.read_sql(query_tmp5,conexion)
                df = pd.DataFrame(datos) 
                #print(df)

                if marca == 'Esprit':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    
                    df.to_excel(ruta_archivo, index=False)
                    
                elif marca == 'Mng':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)
                elif marca == 'Outlet Todo al 50%':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)
                elif marca == 'Brand Store':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)            
                elif marca == 'Carrera':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)            
                elif marca == 'Chevignon':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)            
                elif marca == 'Rifle':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)   
                elif marca == 'Americanino':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False) 
                elif marca == 'Naf Naf':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)    
                elif marca == 'American Eagle':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)
                elif marca == 'G-star':
                    fecha_df = df['periodo'].mode()[0]
                    fecha = str(fecha_df)
                    
                    ruta_archivo = f'C:\\Users\\practclientes\\OneDrive - GCO\\Escritorio\\Carpetas\\Capitalizacion_tiendas\\{fecha}_{marca}.xlsx'
                    df.to_excel(ruta_archivo, index=False)               
                else:
                    print("Error")


                total_marcas.append(df)
                        
            except pyodbc.Error as e:
                print(f'Error al intentar Conectarse:', e)
                    
            finally:
                        # Cerrar el cursor y la conexión después de cada iteración
                cursor.close()
                conexion.close()
        

    ruta_grande = 'O:\\Organizacion\\Publica\\Clientes_CRM\\Capitalizacion_tiendas'
    ruta_base = Path(r'C:\Users\practclientes\OneDrive - GCO\Escritorio\Carpetas\Capitalizacion_tiendas')
    ruta_carpeta = ruta_base
    
    

        
    for contenido in ruta_carpeta.iterdir():
        shutil.move(str(contenido), ruta_grande)


    def copiar_texto():
        root.clipboard_clear()
        root.clipboard_append(labelrut.cget("text"))

    font_txt = Font(family='Arial', size=13)

    labelcon = tk.Label(text="Los datos han pasado a la ruta:", font=font_txt)
    labelrut = tk.Label(text='O:\Organizacion\Publica\Clientes_CRM\Capitalizacion_tiendas', font=font_txt)
    labelcon.pack(pady=10)
    labelrut.pack(pady=8)

    boton_copiar = tk.Button(root, text="Copiar ruta", command=copiar_texto)
    boton_copiar.pack(pady=5)



    

#Con esta funcion se crean las cajas de texto
def crear_marco_con_texto(root, texto):
    frame = tk.Frame(root, borderwidth=1, relief="solid")  # Configurar el borde y el relieve del marco
    frame.pack(side="left", padx=2, pady=10)   # Empaquetar el marco con relleno
    
    label = tk.Label(frame, text=texto, font=("Arial", 16))
    label.pack( padx=10, pady=10)

    return frame


#Esta funcion cambia el color cuando se pasa encima con el mouse
def cambiar_color(event):
    button.config(bg='black')
    button.config(fg='white')


#Esta funcion restaura el color cuando el mouse ya no está encima
def restaurar_color(event):
    button.config(bg='SystemButtonFace')
    button.config(fg='black')



root= tk.Tk()
root.title("Automatización capitalización Naf Naf")
root.geometry("1350x370")

font_tit = Font(family="Arial", weight='bold',  size=20)
titulo = tk.Label(root, text="Marcas a las que se generan archivos", font=font_tit)
titulo.pack(pady=20)


cont = tk.Frame(root)
cont.pack()
marcast = ['Esprit','Mng','Outlet Todo al 50%','Brand Store','Carrera','Chevignon','Rifle','Americanino','Naf Naf','American Eagle','G-star']




for marcat in marcast:
    marco = crear_marco_con_texto(cont, marcat)

btn_font = Font(family='Arial',size=15)
button = tk.Button(root, text="Generar historico de datos"  , padx=50, pady=10, font=btn_font, command=crear_excel)
button.pack()

button.bind("<Enter>", cambiar_color)
button.bind("<Leave>", restaurar_color)

root.mainloop()
