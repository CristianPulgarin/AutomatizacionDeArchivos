/*
FECHA DE CREACI�N: 2023-04-21 
FECHA DE MODIFICACI�N: 2023-05-19 

MODIFICADO POR: Sebastian Gaviria Jaramillo

*/

/*****QUERY RETO 1-CONOCIMIENTO DE LOS CLIENTES-CAPITALIZACIONES *******/
DECLARE @marcat varchar(20)
SET @marcat = 'grupooooo'

DECLARE @marca varchar(20)
SET @marca = 'marcaaa'

DECLARE @GrupoCRM AS INT

SELECT @GrupoCRM = idx_grupo_crm
FROM dbo.dim_Grupo_CRM 
WHERE nombre_grupo = @marca



-- Obtener la fecha actual
DECLARE @FechaActual AS DATE
SET @FechaActual = GETDATE()
-- Convertir la fecha actual a un entero en formato AAAAMMDD
DECLARE @FechaActualEntera AS INT
SET @FechaActualEntera = CAST(YEAR(@FechaActual) * 10000 + MONTH(@FechaActual) * 100 + DAY(@FechaActual) AS INT)





-- Obtener el primer d�a del mes actual
DECLARE @PrimerDiaMesActual AS DATE
SET @PrimerDiaMesActual = DATEADD(MONTH, DATEDIFF(MONTH, 0, @FechaActual), 0)


-- Convertir el primer d�a del mes actual a un entero en formato AAAAMMDD
DECLARE @PrimerDiaMesActual_Int AS INT
SET @PrimerDiaMesActual_Int = CAST(YEAR(@PrimerDiaMesActual) * 10000 + MONTH(@PrimerDiaMesActual) * 100 + DAY(@PrimerDiaMesActual) AS INT)

 

DECLARE @cambioMesAnterior AS INT

SET @cambioMesAnterior = 9
-- Obtener la fecha de un mes anterior

DECLARE @FechaMesAnterior AS DATE
SET @FechaMesAnterior = DATEADD(MONTH, @cambioMesAnterior , @PrimerDiaMesActual)


-- Convertir la fecha de un mes anterior a un entero en formato AAAAMMDD
DECLARE @FechaMesAnteriorEntera AS INT
SET @FechaMesAnteriorEntera = CAST(YEAR(@FechaMesAnterior) * 10000 + MONTH(@FechaMesAnterior) * 100 + DAY(@FechaMesAnterior) AS INT)

DECLARE @cambioDosMesAnt AS INT

SET @cambioDosMesAnt = 10
-- Obtener la fecha de dos meses anteriores
DECLARE @FechaDosMesesAntes AS DATE
SET @FechaDosMesesAntes = DATEADD(MONTH, @cambioDosMesAnt , @PrimerDiaMesActual)



-- Convertir la fecha de dos meses anteriores a un entero en formato AAAAMMDD
DECLARE @FechaDosMesesAntesEntera AS INT
SET @FechaDosMesesAntesEntera = CAST(YEAR(@FechaDosMesesAntes) * 10000 + MONTH(@FechaDosMesesAntes) * 100 + DAY(@FechaDosMesesAntes) AS INT)



;WITH temp_clientes AS (

SELECT	A.[ID Cliente],
A.Identificacion
FROM  [dbo].v_Cliente AS A
INNER JOIN dbo.v_Cliente_Grupo AS B
ON A.[ID Cliente] = B.[ID Cliente]
WHERE B.[ID Grupo CRM] = @GrupoCRM


),

temp_dosMeses_ant AS (

SELECT A.[ID Cliente]
,A.Identificacion
,B.[ID Tienda Mayor Frecuencia],
CASE 
WHEN B.Segmento IS NOT NULL THEN 1 ELSE 0 END AS Seg_2mes_ant
	 
FROM temp_clientes AS A
INNER JOIN [dbo].[v_SegmentacionClientes] AS B 
ON A.[ID Cliente] = B.[ID Cliente] 
WHERE B.[ID Tiempo]= @FechaDosMesesAntesEntera
AND B.[ID Grupo CRM] = @GrupoCRM

),


temp_unMes_ant AS (

SELECT
A.[ID Cliente]
,A.identificacion
,B.[ID Tienda Mayor Frecuencia]
,CASE 
WHEN B.Segmento IS NOT NULL THEN 1 ELSE 0 END AS Seg_mes_ant
FROM temp_clientes AS A
INNER JOIN [dbo].[v_SegmentacionClientes] AS B
ON A.[ID Cliente] = B.[ID Cliente]
WHERE B.[ID Tiempo] = @FechaMesAnteriorEntera
AND B.[ID Grupo CRM] = @GrupoCRM
),


tmp_clientes_tiendas AS (

SELECT COALESCE(C.Identificacion,D.Identificacion) AS identificacion
,COALESCE(D.[ID Tienda Mayor Frecuencia],C.[ID Tienda Mayor Frecuencia]) AS [ID Tienda Mayor Frecuencia]
,CASE 
WHEN C.Seg_2mes_ant IS NOT NULL THEN 1 ELSE 0 END AS Seg_2mes_ant	
,CASE 
WHEN D.Seg_mes_ant IS NOT NULL THEN 1 ELSE 0 END AS Seg_mes_ant	
,CASE
WHEN ISNULL(C.Seg_2mes_ant,0)	= ISNULL(D.Seg_mes_ant,0) THEN 'Mismos Clientes'
WHEN ISNULL(C.Seg_2mes_ant,0) > ISNULL (D.Seg_mes_ant,0) THEN 'Inactivo' ELSE 'Nuevo o Recuperado' END AS Resultado,
CASE 
WHEN  C.[ID Cliente] IS NULL THEN 1 ELSE 0 END AS es_nuevo
FROM temp_dosMeses_ant AS C
FULL OUTER JOIN temp_unMes_ant AS D
ON C.[ID Cliente] = D.[ID Cliente]
)


SELECT
A.Resultado,
@marcat AS Marca
,A.[ID Tienda Mayor Frecuencia]
,B.nombre_tienda
,B.grupo_tienda
,B.canal AS [Canal Tienda],
Zona_Comercial as region
,COUNT(identificacion) AS Conteo,
@FechaDosMesesAntes AS periodo
FROM tmp_clientes_tiendas AS A
INNER JOIN dbo.dim_tienda AS B
ON A.[ID Tienda Mayor Frecuencia] = B.idx_tienda

--where Resultado='Nuevo'
GROUP BY A.Resultado, A.[ID Tienda Mayor Frecuencia],B.nombre_tienda,Zona_Comercial,B.grupo_tienda, B.canal
ORDER BY 2,1